const donate=document.getElementById("blindfoldToggle");

donate.addEventListener("click",()=>{

    window.open("https://buymeacoffee.com/akshaydev2882", "_blank");


})
